"Project IGI2: Covert Strike"
23/01/03


I.	INSTALLING THE GAME
II.	RUNNING THE GAME
III.	STARTING AND JOINING A MULTIPLAYER GAME
IV.	HARDWARE REQUIREMENTS
V.	PERFORMANCE TWEAKS
VI.	KNOWN ISSUES



I.	INSTALLING THE GAME:
============================

NOTE: Avoid minimising the installer during install.

Insert Disc 1 into your CD/DVD drive. If you have Autorun enabled the game should start installing immediately. If Autorun is disabled, browse to the CD and double-click on 'setup.exe'.
You will be prompted for your choice of language for the installer program - select it from the drop-down list.
You will then be asked to enter the directory you wish to install the game to.
After a few minutes you will then be asked to insert Disc 2 to continue the install. Swap Disc 1 for Disc 2 and select 'OK'.



II.	RUNNING THE GAME:
=========================

After you install "Project IGI2: Covert Strike" there will be an "IGI 2" shortcut on your desktop. Double-click this to start the game.
Alternatively you can start the game by going to: Start Menu -> Programs -> Codemasters -> IGI 2 -> Play IGI 2.



III.	STARTING AND JOINING A MULTIPLAYER GAME:
================================================

1. Joining a Multiplayer game:
------------------------------

- Start the game and select 'Multiplayer'.
- Then choose 'Join Game' and click on 'SEARCH LAN' to find all available games on a LAN or 'SEARCH INTERNET' to find all available servers online. For the latter option you need to be already connected to the internet.
- On this screen you can enter a name for yourself and an IP address of a server if you know one.
- Choose the game you wish to join, using the option at the top of the list to sort by number of players, ping and name, and then click 'JOIN'.
- The game will then load to the 'Select Team' screen.


2. Starting a Multiplayer game:
-------------------------------

- Start the game and select 'Multiplayer'. Then choose 'Start Server'.
- Enter your name and the server name at the top of the screen.
- Click on 'Map List' to choose the map(s) you wish to play, selecting 'OK' when you're finished.
- You can also set the maximum number of players you wish to allow on the server, the number of spectators, the port number, whether weapons dropped by enemies will remain to be picked up, whether healthpacks are allowed, or whether you wish to start this game as a dedicated server. NOTE: if you choose this final option you will not be able to play the game on this PC. See below for information on Dedicated Servers.
- Click 'OK' to start the game.
- The game will then load to the 'Select Team' screen.


3. Setting up a dedicated server for a Multiplayer game:
--------------------------------------------------------

- Create a shortcut to 'igi2.exe', right-click on it and select 'Properties' and add 'window quiet serverdedicated port26001 level02' after '...igi2.exe' in the 'Target:' box. Use this shortcut to run a dedicated server. It will display as a black window which means the server is running. The list of multiplayer maps is:

level01 = Redstone
level02 = Forestraid
level03 = Sandstorm
level04 = Timberland
level05 = Chinese Temple

The available port numbers are port26001 -> port26014



IV.	HARDWARE REQUIREMENTS:
==============================

(i) Minimum Requirements
(ii) Recommended Requirements
(iii) Supported Graphics Cards


(i) Minimum Requirements

	Windows 98/ME/2000/XP
	DirectX 8.1
	Pentium III or Athlon at 700Mhz
	128Mb RAM
	Supported 32Mb Graphics Card
	DirectX 8.1 Compatible Sound Card
	8x CD-ROM
	1.9Gb Hard Disk Space
	(1.4Gb for game, 500Mb free after installation)

(ii) Recommended Requirements

	Windows 98/ME/2000/XP 
	DirectX 8.1
	Pentium 3/4 or Athlon at 1.2Ghz
	512Mb RAM
	Supported 64Mb Graphics Card
	DirectX 8.1 Compatible Sound Card
	32x CD-ROM
	1.9Gb Hard Disk Space
	(1.4Gb for game, 500Mb free after installation)


(iii) Supported Graphics Cards

	3dfx Voodoo 4/5
	ATI Radeon, Radeon 7xxx/8xxx/9xxx
	Matrox G400, G450, G550, Parhelia
	Nvidia Riva TNT 2, GeForce 256/2/3/4
	SiS Xabre



V.	PERFORMANCE TWEAKS:
===========================


If you are having problems getting IGI2 to run well on your machine, please read on.

In the graphics settings window, there are quite a few options. The list below is split into three sections, processor, GFX card and RAM. Whichever area of your system is the lowest / oldest out of these, try the options below for that part of your hardware. Don't do them all at once, tune them one at a time.

Note that resolution changes make very little difference at all for IGI2 unless you have a really old graphics card.

----------------------------------

Processor - if your processor is 1GHz or below, make some changes to these settings:

1. Terain detail slider - this is very expensive. Note dropping the terrain slider will cause the terrain to morph (also, note that you can increase this to max to cure terrain warping if you have a very good machine (2GHz or above)).

2. All these are equally important - Lens Flares, Bullet Decals, Wind on Trees. Turn them off 1 by 1, keeping the one you prefer the most till last.

3. Water detail - only change this if your GFX card doesn't support hardware vertex shaders. Anything GF3 or higher that is NOT an MX card, and anything Radeon 8500 above will support this.

4. High quality forests - this will have a very big impact on improving your processor speed, but I list it as no. 4 as it also makes the game look a lot worse. If you don't mind the look of the low quality forests, this should help processor usage quite a bit.

5. Model detail - careful with this one, again can make the game look bad if dropped.

---------------------------------------


GFX card

1. Texture filtering - make sure this is not set to Anisotropic, very few cards can handle this. Bilinear is the lowest resource hit, but there's not too much difference between bilinear and trilinear unless you have a really old card.

2. Full screen antialiasing may also produce a big performance hit. Make sure to turn it off if you don't have one of latest DirectX8 video cards with at least 64Mb of video RAM.

3. Disable Texture Compression - set this to 'No' to improve performance (this is very, very important if you have a 32MB GFX card).

4. Texture detail

5. Stencil shadows

6. High quality forests (this may have a bigger effect on performance than changing stencil shadows, but the hit on visuals is worse, so it is listed lower).

7. Water detail

8. Lens flares

--------------------------------------

RAM

1. Texture compression

2. Texture detail

---------------------------------------


If these changes don't help your performance of IGI2 or you are having other problems please visit the 'Problem Solving' forum at http://community.codemasters.com/forum/forumdisplay.php?s=&forumid=4



VI.	KNOWN ISSUES:
=====================


1. Terrain morphs as the player moves around/distant players and AI seem to be walking in the air

DESCRIPTION:	As the player walks around they see the landscape stretching and growing in the distance.

SOLUTION:	Increase the terrain detail level by using Terrain Detail slider in the Graphics Configuration menu. (Available only when Graphics Detail is in Custom position)


2. ATi Radeon texture flickering issues

DESCRIPTION: 	Game displays graphical distortion with Force Software Vertex Processing set to YES. There may also be graphical issues with Radeon 7200/7500/8500/9000 cards.

SOLUTION:	Graphical options must have Force Software Vertex Processing to YES in order to run the game with this card with the latest drivers. Unfortunately this causes graphical errors. This is a driver issue to be fixed by ATi. For owners of Radeon 8500, 9000 it is recommended to roll back to Catalyst 02.3 drivers (see p.7) and set Force Software Vertex Processing set to NO.


3. GeForce3/4, Radeon 9700 plain ground texture if Force Software Vertex Processing 'ON'

DESCRIPTION:	If Force Software Vertex Processing is set to ON with the above cards, all ground textures disappear

SOLUTION:	Set this option to OFF


4. Matrox Parhelia graphics problems if Force Software Vertex Processing 'ON'

DESCRIPTION:	There are black jagged texture corruptions if Force Software Vertex Processing is set to ON with the above card.

SOLUTION:	Set the option to OFF.

5. GeForce4 Ti 4600 0x0x0 resolution

DESCRIPTION:	A resolution of 0x0x0 may appear in the graphics settings for this card

SOLUTION:	Do not use this resolution.


6. Uninstaller doesn't remove entire game

DECRIPTION:	When the game uninstalled, there are some files left behind in the IGI2 directory

SOLUTION:	Delete the files manually, they are no longer needed.


7. Game locks up/reboots PC on loading a level with Radeon cards

DESCRIPTION:	Game locks up or reboots machine immediately after a level is loaded when using ATI Radeon 8500, 9000.

SOLUTION:	Roll back to 2.3 Catalyst drivers (6.13.10.6166). Those can be found at http://mirror.ati.com/support/products/radeonwinxppreviousdrivers.html for Windows XP/2000 and at http://mirror.ati.com/support/products/radeonwinmepreviousdrivers.html for Windows ME.
If it is not possible, enable "Force Software Vertex Processing" in the Graphics Configuration menu.


8. Terrain and water have wrong colours or texture flickering

DESCRIPTION:	Terrain or water have incorrect colours or texture flicking on nVidia GForce3 or GForce4 Ti.

SOLUTION:	Make sure that "Force Software Vertex Processing" option in the advanced options menu is unchecked.


9. Slow framerate on Voodoo 5

DESCRIPTION:	Choppy framerate, big slowdowns when running the game on Voodoo5.

SOLUTION:	Set "Disable texture compression" option in the advanced options to "No". Pull "Texture detail" slider menu to the left in order to decrease texture resolution.


10. Terrain texture flickering, may appear when using different video cards.

DESCRIPTION:	There are black jagged texture corruptions looking like different layers of terrain textures seep through each other.

SOLUTION:	Add 'zbias' or 'zbias2' to the command line option for IGI2 e.g. - Create a shortcut to 'igi2.exe', right-click on it and select 'Properties' and add "zbias" or "zbias2" (without the inverted commas) after '...igi2.exe' in the 'Target:' box. Now run the game using this shortcut.


11. Can't add more than 16 player profiles

DESCRIPTION:	When you try to add another player profile there is a beep, but nothing happens.

SOLUTION:	You already have 16 profiles. This is the maximum you can have. To create new ones you must delete some of the others first.


12. Can't add a player profile when there are less than 16 profiles created

DESCRIPTION:	If you try to add another player profile when there are less than 16 already created there is a beep, but nothing happens.

SOLUTION:	You are trying to create a profile with a player name that is already used. All player profile names must be unique.


(c) 2003 Innerloop Studios and The Codemasters Software Company Limited ("Codemasters"). All rights reserved. "Codemasters"(r) is a registered trademark owned by Codemasters.  "Covert Strike"(TM) and "GENIUS AT PLAY"(TM) are trademarks of Codemasters. IGI(TM) is a trademark of Innerloop Studios. Developed by Innerloop Studios. Published by Codemasters. Dolby and the double D symbol are trademarks of Dolby Laboratories All other copyrights or trademarks are the property of their respective owners.

